<?php

/* partials/menu.html */
class __TwigTemplate_04446fc5e825294aeb0a281d0c25838c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- left menu starts -->
<div class=\"span2 main-menu-span\">
    <div class=\"well nav-collapse sidebar-nav\">
        <ul class=\"nav nav-tabs nav-stacked main-menu\">
            <li class=\"nav-header hidden-tablet\">Главное меню</li>
            <li><a class=\"ajax-link\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/\"><i class=\"icon icon-black icon-home\"></i><span class=\"hidden-tablet\"> Главная </span></a></li>
            ";
        // line 7
        if (((isset($context["roleuser"]) ? $context["roleuser"] : null) > 1)) {
            // line 8
            echo "            <li><a class=\"ajax-link\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
            echo "/news\"><i class=\"icon-eye-open\"></i><span class=\"hidden-tablet\"> Новости</span></a></li>
            <li><a class=\"ajax-link\" href=\"";
            // line 9
            echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
            echo "/articles\"><i class=\"icon-edit\"></i><span class=\"hidden-tablet\"> Статьи</span></a></li>
            ";
        }
        // line 10
        echo " 
            <li><a class=\"ajax-link\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/shorturl\"><i class=\"icon icon-black icon-link\"></i><span class=\"hidden-tablet\"> Сокращение ссылок </span></a></li>
            <li><a class=\"ajax-link\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/analiz/seo\"><i class=\"icon-black icon-list-alt\"></i><span class=\"hidden-tablet\"> Анализ сайта</span></a></li>
            ";
        // line 13
        if (((isset($context["roleuser"]) ? $context["roleuser"] : null) > 1)) {
            // line 14
            echo "            <li><a class=\"ajax-link\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
            echo "/registration\"><i class=\"icon-font\"></i><span class=\"hidden-tablet\"> Регистрация</span></a></li>
            <li><a class=\"ajax-link\" href=\"gallery.html\"><i class=\"icon-picture\"></i><span class=\"hidden-tablet\"> Gallery</span></a></li>
            <li class=\"nav-header hidden-tablet\">Sample Section</li>
            <li><a class=\"ajax-link\" href=\"table.html\"><i class=\"icon-align-justify\"></i><span class=\"hidden-tablet\"> Tables</span></a></li>
            <li><a class=\"ajax-link\" href=\"calendar.html\"><i class=\"icon-calendar\"></i><span class=\"hidden-tablet\"> Calendar</span></a></li>
            <li><a class=\"ajax-link\" href=\"grid.html\"><i class=\"icon-th\"></i><span class=\"hidden-tablet\"> Grid</span></a></li>
            <li><a class=\"ajax-link\" href=\"file-manager.html\"><i class=\"icon-folder-open\"></i><span class=\"hidden-tablet\"> File Manager</span></a></li>
            <li><a href=\"tour.html\"><i class=\"icon-globe\"></i><span class=\"hidden-tablet\"> Tour</span></a></li>
            <li><a class=\"ajax-link\" href=\"icon.html\"><i class=\"icon-star\"></i><span class=\"hidden-tablet\"> Icons</span></a></li>
            <li><a href=\"error.html\"><i class=\"icon-ban-circle\"></i><span class=\"hidden-tablet\"> Error Page</span></a></li>
            <li><a href=\"login.html\"><i class=\"icon-lock\"></i><span class=\"hidden-tablet\"> Login Page</span></a></li>
            ";
        }
        // line 26
        echo "        </ul>
        
    </div><!--/.well -->
 
</div><!--/span-->
<!-- left menu ends -->";
    }

    public function getTemplateName()
    {
        return "partials/menu.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 26,  55 => 14,  53 => 13,  45 => 11,  42 => 10,  26 => 6,  51 => 28,  36 => 15,  34 => 14,  19 => 1,  438 => 195,  433 => 101,  428 => 8,  423 => 7,  418 => 6,  414 => 79,  382 => 48,  378 => 46,  367 => 38,  363 => 37,  359 => 36,  355 => 35,  351 => 34,  347 => 33,  343 => 32,  339 => 31,  335 => 30,  331 => 29,  327 => 28,  323 => 27,  319 => 26,  315 => 25,  311 => 24,  307 => 23,  294 => 13,  286 => 8,  282 => 7,  278 => 6,  275 => 5,  272 => 4,  267 => 196,  265 => 195,  261 => 194,  256 => 192,  251 => 190,  246 => 188,  241 => 186,  236 => 184,  231 => 182,  226 => 180,  221 => 178,  216 => 176,  211 => 174,  206 => 172,  199 => 168,  195 => 167,  191 => 166,  187 => 165,  183 => 164,  177 => 161,  172 => 159,  167 => 157,  162 => 155,  157 => 153,  152 => 151,  147 => 149,  142 => 147,  137 => 145,  132 => 143,  127 => 141,  122 => 139,  117 => 137,  112 => 135,  107 => 133,  102 => 131,  97 => 129,  92 => 127,  87 => 124,  84 => 122,  63 => 102,  61 => 101,  47 => 90,  41 => 86,  39 => 85,  32 => 8,  30 => 7,  25 => 1,  79 => 17,  70 => 14,  66 => 12,  62 => 11,  58 => 33,  56 => 8,  52 => 6,  49 => 12,  43 => 4,  37 => 9,  31 => 2,);
    }
}
