<?php

/* partials/topbar.html */
class __TwigTemplate_f83b37ae76bfd57b882219f750b0ad20 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo " <div class=\"navbar\">
            <div class=\"navbar-inner\">
                <div class=\"container-fluid\">
                    <a class=\"btn btn-navbar\" data-toggle=\"collapse\" data-target=\".top-nav.nav-collapse,.sidebar-nav.nav-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </a>
                    <a class=\"brand\" href=\"/\"><span>UserSet</span></a>

                    <!-- theme selector starts -->

                    <!-- theme selector ends -->
                    ";
        // line 14
        if (((isset($context["roleuser"]) ? $context["roleuser"] : null) > 0)) {
            // line 15
            echo "                    <!-- user dropdown starts -->
                    <div class=\"btn-group pull-right\" >
                        <a class=\"btn dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                            <span class=\"hidden-phone\">Профиль</span>
                            <span class=\"caret\"></span>
                        </a>
                        <ul class=\"dropdown-menu\">
                            <li><a href=\"/settings\" rel=\"nofollow\">Настройки</a></li>
                            <li><a href=\"/login/logout\" rel=\"nofollow\">Выход</a></li>
                        </ul>
                    </div>
                    <!-- user dropdown ends -->
                    ";
        } else {
            // line 28
            echo "                    <div class=\"btn-group pull-right\">
                        <a class=\"btn\" href=\"/login\">Вход</a>
                        <a class=\"btn\" href=\"/registration\">Регистрация</a>
                    </div>
                    ";
        }
        // line 33
        echo "                </div>
            </div>
        </div>
       ";
    }

    public function getTemplateName()
    {
        return "partials/topbar.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 28,  36 => 15,  34 => 14,  19 => 1,  438 => 195,  433 => 101,  428 => 8,  423 => 7,  418 => 6,  414 => 79,  382 => 48,  378 => 46,  367 => 38,  363 => 37,  359 => 36,  355 => 35,  351 => 34,  347 => 33,  343 => 32,  339 => 31,  335 => 30,  331 => 29,  327 => 28,  323 => 27,  319 => 26,  315 => 25,  311 => 24,  307 => 23,  294 => 13,  286 => 8,  282 => 7,  278 => 6,  275 => 5,  272 => 4,  267 => 196,  265 => 195,  261 => 194,  256 => 192,  251 => 190,  246 => 188,  241 => 186,  236 => 184,  231 => 182,  226 => 180,  221 => 178,  216 => 176,  211 => 174,  206 => 172,  199 => 168,  195 => 167,  191 => 166,  187 => 165,  183 => 164,  177 => 161,  172 => 159,  167 => 157,  162 => 155,  157 => 153,  152 => 151,  147 => 149,  142 => 147,  137 => 145,  132 => 143,  127 => 141,  122 => 139,  117 => 137,  112 => 135,  107 => 133,  102 => 131,  97 => 129,  92 => 127,  87 => 124,  84 => 122,  63 => 102,  61 => 101,  47 => 90,  41 => 86,  39 => 85,  32 => 80,  30 => 4,  25 => 1,  79 => 17,  70 => 14,  66 => 12,  62 => 11,  58 => 33,  56 => 8,  52 => 6,  49 => 91,  43 => 4,  37 => 3,  31 => 2,);
    }
}
