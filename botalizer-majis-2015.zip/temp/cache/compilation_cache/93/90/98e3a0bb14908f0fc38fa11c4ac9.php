<?php

/* partials/result1.twig */
class __TwigTemplate_939098e3a0bb14908f0fc38fa11c4ac9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if (((isset($context["status_analiz"]) ? $context["status_analiz"] : null) == true)) {
            // line 2
            echo "<style>
        .thumbnail img,.thumbnail > a{
            z-index:2;
            height:220px;
            width:200px;
            position:relative;
            display: block;
        }
        .thumbnail {
            background-color: white;
            z-index: 2;
            position: relative;
            margin-bottom: 0px !important;
        }
    </style>
\t
    <div class=\"row-fluid sortable\">
        <div class=\"box span12\">
            <div class=\"box-header well\" data-original-title>
                <h2><img src='http://favicon.yandex.net/favicon/";
            // line 21
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "'> Анализ сайта - основные показатели и характеристики - ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "</h2>
                <div class=\"box-icon\">
                    <a href=\"#\" class=\"btn btn-minimize btn-round\"><i class=\"icon-chevron-up\"></i></a>
                    <a href=\"#\" class=\"btn btn-close btn-round\"><i class=\"icon-remove\"></i></a>
                </div>
            </div>
            <div class=\"box-content\">
                <div class=\"row-fluid\">
                    <div class=\"span3\">
                        <ul class=\"thumbnails\">
                            <li id=\"image-01\" class=\"thumbnail\" style=\"background:url(";
            // line 31
            echo twig_escape_filter($this->env, (isset($context["screen_url"]) ? $context["screen_url"] : null), "html", null, true);
            echo ")\" ><a href=\"";
            echo twig_escape_filter($this->env, (isset($context["screen_url"]) ? $context["screen_url"] : null), "html", null, true);
            echo "\"><img alt=\"";
            echo twig_escape_filter($this->env, (isset($context["title_url"]) ? $context["title_url"] : null), "html", null, true);
            echo "\" title=\"Скриншот сайта ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["screen_url"]) ? $context["screen_url"] : null), "html", null, true);
            echo "\" ></a></li>
                        </ul>
                    </div>
                    <div class=\"span9\">
                        <h4>";
            // line 35
            echo (isset($context["title_url"]) ? $context["title_url"] : null);
            echo "</h4>
                        <hr>
                        <p><b>Домен:</b> <a href=\"http://";
            // line 37
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "\" rel=\"nofollow\" title=\"";
            echo (isset($context["title_url"]) ? $context["title_url"] : null);
            echo "\" target=\"_blank\">";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "</a> 
\t\t\t\t\t\t    <script type=\"text/javascript\" src=\"//yandex.st/share/share.js\" charset=\"utf-8\"></script>
\t\t\t\t\t\t\t<!--noindex-->
\t\t\t\t\t\t\t<span class=\"yashare-auto-init\" data-yashareL10n=\"ru\" data-yashareType=\"button\" data-yashareQuickServices=\"\" ></span> <!--/noindex-->
\t\t\t\t\t\t\t
                       ";
            // line 42
            if (((isset($context["update_date"]) ? $context["update_date"] : null) == false)) {
                echo "     
                                <span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" href=\"";
                // line 43
                echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
                echo "/update/";
                echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
                echo "\" rel=\"nofollow\" title=\"Обновить данные по анализу сайта ";
                echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
                echo "\">Обновить данные анализа</a></span>
                       ";
            } else {
                // line 45
                echo "                                <span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" data-rel=\"popover\" data-placement=\"left\" data-content=\"Обновить можно будет через сутки после анализа сайта. Время обновления ";
                echo twig_escape_filter($this->env, (isset($context["update_date"]) ? $context["update_date"] : null), "html", null, true);
                echo "\" title=\"Обновление данных\">Обновить данные анализа</a></span>
                       ";
            }
            // line 47
            echo "                            </p>
\t\t\t\t\t\t\t";
            // line 48
            if ((isset($context["description_url"]) ? $context["description_url"] : null)) {
                echo "<p><b>Описание:</b> ";
                echo (isset($context["description_url"]) ? $context["description_url"] : null);
                echo "</p>";
            }
            // line 49
            echo "                            ";
            if ((isset($context["keywords_url"]) ? $context["keywords_url"] : null)) {
                echo "<p><b>Ключевые слова:</b> ";
                echo (isset($context["keywords_url"]) ? $context["keywords_url"] : null);
                echo "</p>";
            }
            // line 50
            echo "                            ";
            if ((isset($context["h1_url"]) ? $context["h1_url"] : null)) {
                echo "<p><b>H1:</b> <i>";
                echo (isset($context["h1_url"]) ? $context["h1_url"] : null);
                echo "</i></p>";
            }
            // line 51
            echo "                            <p><b>Размер страницы:</b> <span>";
            echo twig_escape_filter($this->env, (isset($context["size_url"]) ? $context["size_url"] : null), "html", null, true);
            echo " Кбайт</span></p>
                            <p><b>Количество исходящих ссылок:</b> <span class=\"label label-important\"> ";
            // line 52
            echo twig_escape_filter($this->env, (isset($context["link_out_url"]) ? $context["link_out_url"] : null), "html", null, true);
            echo "</span> | <a href=\"#link_out_url\">Подробнее</a></p>
                            <p><b>Количество внутренних ссылок:</b> <span class=\"label label-important\">";
            // line 53
            echo twig_escape_filter($this->env, (isset($context["link_count_site_url"]) ? $context["link_count_site_url"] : null), "html", null, true);
            echo "</span> | <a href=\"#link_count_site_url\">Подробнее</a></p>
                            <p><b>Количество изображений:</b> <span class=\"label label-important\">";
            // line 54
            echo twig_escape_filter($this->env, (isset($context["link_count_image_url"]) ? $context["link_count_image_url"] : null), "html", null, true);
            echo "</span>  | <a href=\"#link_count_image_url\">Подробнее</a></p>                 
                            <p><b>IP адрес сайта (";
            // line 55
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo ") :</b> <span class=\"label label-important\">";
            echo twig_escape_filter($this->env, (isset($context["ip_url"]) ? $context["ip_url"] : null), "html", null, true);
            echo "</span> | <b>Всего сайтов на этом IP (";
            echo twig_escape_filter($this->env, (isset($context["ip_url"]) ? $context["ip_url"] : null), "html", null, true);
            echo ") :</b> <span class=\"label label-important\">";
            echo twig_escape_filter($this->env, (isset($context["ip_url_site_count"]) ? $context["ip_url_site_count"] : null), "html", null, true);
            echo "</span> | <!--noindex--><a href=\"";
            echo twig_escape_filter($this->env, (isset($context["link_to_bing_more_ip"]) ? $context["link_to_bing_more_ip"] : null), "html", null, true);
            echo "\" rel=\"nofollow\"> Смотреть список </a><!--/noindex--></p>
                            <p><!--noindex--><b>Рекомендация:</b><a href=\"http://goo.gl/qb7SU\" rel=\"nofollow\"> Хостинг от 44 рублей (Германия) / Лучший VPS хостинг</a><!--/noindex--></p>
\t\t\t\t\t\t\t<p><b>Имя хоста сайта - <i>";
            // line 57
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "</i>  :</b> <span class=\"label label-important\">";
            echo twig_escape_filter($this->env, (isset($context["ip_hosting_url"]) ? $context["ip_hosting_url"] : null), "html", null, true);
            echo "</span> </p>
                            <p><b>Адрес расположения датацентра :</b> <img style=\"width: 23px;\" alt=\"Страна расположения датацентра :";
            // line 58
            echo twig_escape_filter($this->env, (isset($context["server_countryName"]) ? $context["server_countryName"] : null), "html", null, true);
            echo " \" title=\"Страна расположения датацентра :";
            echo twig_escape_filter($this->env, (isset($context["server_countryName"]) ? $context["server_countryName"] : null), "html", null, true);
            echo " \" src='/web/im/flag/";
            echo twig_escape_filter($this->env, (isset($context["server_countryName"]) ? $context["server_countryName"] : null), "html", null, true);
            echo ".gif' /> ";
            echo twig_escape_filter($this->env, (isset($context["server_countryName"]) ? $context["server_countryName"] : null), "html", null, true);
            echo " (";
            echo twig_escape_filter($this->env, (isset($context["server_countryCode"]) ? $context["server_countryCode"] : null), "html", null, true);
            echo ") , ";
            echo twig_escape_filter($this->env, (isset($context["server_city"]) ? $context["server_city"] : null), "html", null, true);
            echo " ,";
            echo twig_escape_filter($this->env, (isset($context["server_region"]) ? $context["server_region"] : null), "html", null, true);
            echo " </p>
                        </div>
                    </div> 
                </div>
            </div><!--/span-->
        </div> 
     
\t 
\t 
\t 
\t 
\t
\t 
\t 
\t 
\t 
\t 
\t <div class=\"row-fluid sortable\">
            <div class=\"box span12\">
                <div class=\"box-header well\" data-original-title>
                    <h2>Показания поисковых систем</h2>
                    <div class=\"box-icon\">
                        <a href=\"#\" class=\"btn btn-minimize btn-round\"><i class=\"icon-chevron-up\"></i></a>
                        <a href=\"#\" class=\"btn btn-close btn-round\"><i class=\"icon-remove\"></i></a>
                    </div>
                </div>
                <div class=\"box-content\">
                    <div class=\"row-fluid\">
                        <div class=\"span4\">
                            <h3>Google</h3>
                            <hr>
                            <div class=\"row-fluid\">
                                <div class=\"span12\">
                                    <p><b>Google PageRank:</b><span class=\"pull-right\"><!--noindex--><a href=\"http://goo.gl/DlDHK\" rel=\"nofollow\">Увеличить</a><!--/noindex--> | <span class=\"label label-important\">";
            // line 91
            echo twig_escape_filter($this->env, ((array_key_exists("pr_url", $context)) ? (_twig_default_filter((isset($context["pr_url"]) ? $context["pr_url"] : null), "0")) : ("0")), "html", null, true);
            echo "/10</span></span></p>
                                    <p><b>Страниц в Google:</b><span class=\"pull-right\"><span class=\"label label-important\">";
            // line 92
            echo twig_escape_filter($this->env, (isset($context["index_google"]) ? $context["index_google"] : null), "html", null, true);
            echo "</span></span></p>
                                    <p><b>Упоминание в Google:</b><span class=\"pull-right\"><span class=\"label label-important\">";
            // line 93
            echo twig_escape_filter($this->env, (isset($context["links_google"]) ? $context["links_google"] : null), "html", null, true);
            echo "</span></span></p>
                                    <p><b>Показатель PR:</b><span class=\"pull-right\"><img src='/web/images/google_pr";
            // line 94
            echo twig_escape_filter($this->env, ((array_key_exists("pr_url", $context)) ? (_twig_default_filter((isset($context["pr_url"]) ? $context["pr_url"] : null), "0")) : ("0")), "html", null, true);
            echo ".gif'/></p>
                                </div>
                            </div>
                        </div>
                        <div class=\"span4\">
                            <h3>Яндекс</h3>
                            <hr>
                            <div class=\"row-fluid\">
                                <div class=\"span12\">
                                    <p><b>Яндекс Тиц:</b><span class=\"pull-right\"><!--noindex--><a href=\"http://goo.gl/DlDHK\" rel=\"nofollow\">Увеличить</a><!--/noindex--> | <span class=\"label label-important\">";
            // line 103
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["yandex_cy_url"]) ? $context["yandex_cy_url"] : null), 0), "html", null, true);
            echo "</span></span></p>
                                    <p><b>Cтраниц в Yandex:</b><span class=\"pull-right\"><span class=\"label label-important\">";
            // line 104
            echo twig_escape_filter($this->env, (($this->getAttribute((isset($context["index_yandex"]) ? $context["index_yandex"] : null), 0, array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute((isset($context["index_yandex"]) ? $context["index_yandex"] : null), 0), 0)) : (0)), "html", null, true);
            echo "</span></span></p>
                                    <p><b>Упоминание в Yandex:</b><span class=\"pull-right\"><span class=\"label label-important\">";
            // line 105
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["index_yandex_links"]) ? $context["index_yandex_links"] : null), 0), "html", null, true);
            echo "</span></span></p>
                                    <p><b>Показатель Тиц:</b><span class=\"pull-right\"><img  data-rel=\"tooltip\" data-placement=\"top\" title=\"ТИЦ домена без WWW\" src='http://yandex.ru/cycounter?http://";
            // line 106
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "'/></span></p>
                                </div>

                            </div>
                        </div>
                        <div class=\"span4\">
                            <h3>Alexa</h3>
                            <hr>
                            <div class=\"row-fluid\">
                                <div class=\"span12\">
                                    <p><b>Alexa Rang:</b><span class=\"pull-right\"><span class=\"label label-important\">";
            // line 116
            echo twig_escape_filter($this->env, (isset($context["alexa_rang_url"]) ? $context["alexa_rang_url"] : null), "html", null, true);
            echo "</span></span></p>
                                    <p><b>Упоминание о сайте в Bing:</b><span class=\"pull-right\"><span class=\"label label-important\">";
            // line 117
            echo twig_escape_filter($this->env, (isset($context["links_bing"]) ? $context["links_bing"] : null), "html", null, true);
            echo "</span></span></p>
                                    <p><b>Узнать больше:</b><span class=\"pull-right\"><a class=\"\" href=\"http://www.alexa.com/siteinfo/";
            // line 118
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "\" rel=\"nofollow\">Подробнее</a></span></p>
                                </div>

                            </div>
                        </div>
                    </div> 
                    <hr>
                    <h3>Наличие сайта ";
            // line 125
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " в каталогах поисковых систем</h3>
                    <hr>
                    <div class=\"row-fluid\">
                        <div class=\"span6\">
                            <p><b>Наличие в каталоге Yandex:</b>
                        ";
            // line 130
            if (((isset($context["cat_yandex"]) ? $context["cat_yandex"] : null) == 0)) {
                // line 131
                echo "                                    <b>Нет</b>  |  <a href=\"http://advertising.yandex.ru/catalog.xml\" rel=\"nofollow\" target=\"_blank\">Добавить</a></span>
                        ";
            } else {
                // line 133
                echo "                                    <span class=\"label label-important\">Да</span>   | Найдено страниц: <span class=\"label label-important\">";
                echo twig_escape_filter($this->env, (isset($context["cat_yandex"]) ? $context["cat_yandex"] : null), "html", null, true);
                echo "</span> | <a href=\"http://search.yaca.yandex.ru/yandsearch?text=";
                echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
                echo "&rpt=rs2\" rel=\"nofollow\" target=\"_blank\">Посмотреть</a>
                        ";
            }
            // line 135
            echo "                                </p>
                            </div>
                            <div class=\"span6\">
                                <p>
                                    <b>Наличие в каталоге DMOZ:</b>
                            ";
            // line 140
            if (((isset($context["cat_google"]) ? $context["cat_google"] : null) == 0)) {
                // line 141
                echo "                                    <b>Нет</b>  |  <a href=\"http://www.dmoz.org/add.html\" rel=\"nofollow\" target=\"_blank\">Добавить</a>
                             ";
            } else {
                // line 143
                echo "                                    <span class=\"label label-important\">Да</span>   |  Найдено страниц: <span class=\"label label-important\">";
                echo twig_escape_filter($this->env, (isset($context["cat_google"]) ? $context["cat_google"] : null), "html", null, true);
                echo "</span> | <a href=\"http://www.dmoz.org/search?q=";
                echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
                echo "\" rel=\"nofollow\" target=\"_blank\">Посмотреть</a>
                             ";
            }
            // line 145
            echo "                                </p>
                            </div>
                        </div>
                    </div>
                </div><!--/span-->
            </div> 
                <div class=\"row-fluid sortable\">
                    <div class=\"box span";
            // line 152
            if ((isset($context["liveinternet_graph"]) ? $context["liveinternet_graph"] : null)) {
                echo "6";
            } else {
                echo "12";
            }
            echo "\">
                        <div class=\"box-header well\" data-original-title>
                            <h2>Alexa Rang График</h2>
                            <div class=\"box-icon\">
                                <a href=\"#\" class=\"btn btn-minimize btn-round\"><i class=\"icon-chevron-up\"></i></a>
                                <a href=\"#\" class=\"btn btn-close btn-round\"><i class=\"icon-remove\"></i></a>
                            </div>
                        </div>
                        <div class=\"box-content\">
                            <div class=\"row-fluid\">
                                <div class=\"span12\">
                                    <center><img src=\"http://traffic.alexa.com/graph?c=1&f=555555&u=http://";
            // line 163
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "&u=&u=&u=&u=&r=6m&y=r&z=1&h=355&w=";
            if ((isset($context["liveinternet_graph"]) ? $context["liveinternet_graph"] : null)) {
                echo "500";
            } else {
                echo "1000";
            }
            echo "\" alt=\"Alexa Rang График - сайт ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "\" /> </center>
                                </div>
                            </div> 
                        </div>
                    </div><!--/span-->
    ";
            // line 168
            if ((isset($context["liveinternet_graph"]) ? $context["liveinternet_graph"] : null)) {
                // line 169
                echo "                    <div class=\"box span6\">
                        <div class=\"box-header well\" data-original-title>
                            <h2>LiveInternet График</h2>
                            <div class=\"box-icon\">
                                <a href=\"#\" class=\"btn btn-minimize btn-round\"><i class=\"icon-chevron-up\"></i></a>
                                <a href=\"#\" class=\"btn btn-close btn-round\"><i class=\"icon-remove\"></i></a>
                            </div>
                        </div>
                        <div class=\"box-content\">
                            <div class=\"row-fluid\">
                                <div class=\"span12\">
                                    <img src=\"";
                // line 180
                echo twig_escape_filter($this->env, (isset($context["liveinternet_graph"]) ? $context["liveinternet_graph"] : null), "html", null, true);
                echo "\" alt=\"\" /> 
                                </div>
                            </div> 
                        </div>
                    </div><!--/span-->
    ";
            }
            // line 186
            echo "                </div>


                <div class=\"row-fluid sortable\">
                    <div class=\"box span12\">
                        <div class=\"box-header well\" data-original-title>
                            <h2>Более подробная информация по сайту ";
            // line 192
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "</h2>
                            <div class=\"box-icon\">
                                <a href=\"#\" class=\"btn btn-minimize btn-round\"><i class=\"icon-chevron-up\"></i></a>
                                <a href=\"#\" class=\"btn btn-close btn-round\"><i class=\"icon-remove\"></i></a>
                            </div>
                        </div>
                        <div class=\"box-content\">
                            <h3>Индексация страниц сайта ";
            // line 199
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " поисковыми системами</h3>
                            <hr>
                            <div class=\"row-fluid\">

                                <div class=\"span3\">
                                    <p><b>Яндекс:</b> <span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" href=\"http://yandex.ru/yandsearch?text=";
            // line 204
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "&site=";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "&ras=1&site_manually=true&lr=225\" rel=\"nofollow\" title=\"Проиндексированные страницы сайта ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " в Яндексе\" target=\"_blank\">Смотреть</a></span></p>
                       ";
            // line 212
            echo "                                </div>
                                <div class=\"span3\">
                                    <p><b>Google:</b><span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" href=\"http://www.google.com/search?hl=en&q=site:http://";
            // line 214
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "&newwindow=1&filter=0\" rel=\"nofollow\" title=\"Проиндексированные страницы сайта ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " в Google\" target=\"_blank\">Смотреть</a></span></p>
                                </div>
                                <div class=\"span3\">
                                    <p><b>Bing:</b><span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" href=\"http://www.bing.com/search?q=site%3A";
            // line 217
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "\" rel=\"nofollow\" title=\"Проиндексированные страницы сайта ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " в BING\" target=\"_blank\">Смотреть</a></span></p>
                                </div>
                                <div class=\"span3\">
                                    <p><b>Rambler:</b><span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" href=\"http://nova.rambler.ru/search?query=";
            // line 220
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "&sort=0&oe=1251&limit=50&filter=";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "\" rel=\"nofollow\" title=\"Проиндексированные страницы сайта ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " в Рамблере\" target=\"_blank\">Смотреть</a></span></p>
                                </div>
                            </div> 
                            <hr>
                            <h3>Ссылаются на сайт ";
            // line 224
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " из ...</h3>
                            <hr>
                            <div class=\"row-fluid\">
                                <div class=\"span3\"> 
                                    <p><b>Яндекс:</b><span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" href=\"http://www.google.com/search?hl=en&q=site:http://";
            // line 228
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "&newwindow=1&filter=0\" rel=\"nofollow\" title=\"Ссылки на ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " в Яндексе\" target=\"_blank\">Смотреть</a></span></p>
                                    <p><b>Яндекс картинки:</b><span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" href=\"http://images.yandex.ru/yandsearch?text=";
            // line 229
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "&stype=image\" rel=\"nofollow\" title=\"Ссылки на ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " в Яндекс Картинках\" target=\"_blank\">Смотреть</a></span></p>
                                </div>
                                <div class=\"span3\"> 
                                    <p><b>Яндекс блоги:</b><span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" href=\"http://blogs.yandex.ru/search.xml?text=";
            // line 232
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "\" rel=\"nofollow\" title=\"Ссылки на ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " в Яндекс Блогах\" target=\"_blank\">Смотреть</a></span></p>
                                    <p><b>Сайты из Я-Каталога:</b><span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" href=\"http://yaca.yandex.ru/yca?text=%22";
            // line 233
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "%22\" rel=\"nofollow\" title=\"Ссылки на ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " с сайтов в Яндекс Каталоге\" target=\"_blank\">Смотреть</a></span></p>
                                </div>
                                <div class=\"span3\"> 
                                    <p><b>Google блоги:</b><span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" href=\"http://blogsearch.google.ru/?hl=ru&tab=wb&q=";
            // line 236
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "\" rel=\"nofollow\" title=\"Ссылки на ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " в Google Блогах\" target=\"_blank\">Смотреть</a></span></p>
                                    <p><b>Google:</b><span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" href=\"http://www.google.com/search?hl=en&lr=&ie=UTF-8&q=link%3A";
            // line 237
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "\" rel=\"nofollow\" title=\"Ссылки на ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " в Google Блогах\" target=\"_blank\">Смотреть</a></span></p>
                                </div>
                                <div class=\"span3\"> 
                                    <p><b>Bing:</b><span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" href=\"http://www.bing.com/search?q=-site%3A";
            // line 240
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "+";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "&go=&form=QBNO\" rel=\"nofollow\" title=\"Ссылки на ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " в Bing\" target=\"_blank\">Смотреть</a></span></p>
                                    <p><b>Google картинки:</b><span class=\"pull-right\"><a class=\"btn btn-mini btn-info\" href=\"http://images.google.ru/images?hl=ru&source=imghp&q=";
            // line 241
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "&gbv=2&aq=f\" rel=\"nofollow\" title=\"Ссылки на ";
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " в Bing\" target=\"_blank\">Смотреть</a></span></p>
                                </div>
                            </div>
                        </div><!--/span-->
                    </div> 



                    <div class=\"row-fluid sortable\">
                        <div class=\"box span12\">
                            <div class=\"box-header well\" data-original-title>
                                <h2>Внутренние, внешние ссылки сайта. Картинки на сайте</h2>
                                <div class=\"box-icon\">
                                    <a href=\"#\" class=\"btn btn-minimize btn-round\"><i class=\"icon-chevron-up\"></i></a>
                                    <a href=\"#\" class=\"btn btn-close btn-round\"><i class=\"icon-remove\"></i></a>
                                </div>
                            </div>

                            <div id=\"link_out_url\" class=\"box-content\">
                                <div class=\"row-fluid\">
                                    <div class=\"span12\">
                             ";
            // line 262
            if ($this->getAttribute((isset($context["list_link_out_url"]) ? $context["list_link_out_url"] : null), "href")) {
                echo " 
                                            <table class=\"table table-bordered\">
                                                <caption><h2>Исходящие ссылки с сайта ";
                // line 264
                echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
                echo "</h2></caption>
                                                <thead>
                                                    <tr>
                                                        <th>URL</th>
                                                        <th>Анкор</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                    ";
                // line 272
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["list_link_out_url"]) ? $context["list_link_out_url"] : null), "href"));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
                    // line 273
                    echo "                                                        <tr>
                                                            <td>";
                    // line 274
                    echo twig_escape_filter($this->env, (isset($context["link"]) ? $context["link"] : null), "html", null, true);
                    echo "</td> 
                                                            <td>";
                    // line 275
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["list_link_out_url"]) ? $context["list_link_out_url"] : null), "text"), $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0")), "html", null, true);
                    echo "</td>
                                                        </tr>
                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['link'], $context['_parent'], $context['loop']);
                $context = array_merge($_parent, array_intersect_key($context, $_parent));
                // line 278
                echo "                                                    </tbody>
                                                </table>
                                ";
            }
            // line 281
            echo "                                                <table id=\"link_count_site_url\" class=\"table table-bordered\">
                                                    <caption><h2>Внутренние ссылки сайта ";
            // line 282
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "</h2></caption>
                                                    <thead>
                                                        <tr>
                                                            <th>Анкор</th>
                                                            <th>URL</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                    ";
            // line 290
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["link_site_url"]) ? $context["link_site_url"] : null), "href"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
                // line 291
                echo "                                                            <tr>

                                                                <td>";
                // line 293
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["link_site_url"]) ? $context["link_site_url"] : null), "text"), $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index0")), "html", null, true);
                echo "</td>

                                                                <td>";
                // line 295
                echo twig_escape_filter($this->env, (isset($context["link"]) ? $context["link"] : null), "html", null, true);
                echo "</td> 
                                                            </tr>
                    ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['link'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 298
            echo "                                                        </tbody>
                                                    </table>

                                                    <table id=\"link_count_image_url\" class=\"table table-bordered\">
                                                        <caption><h2>Список изображений сайта ";
            // line 302
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "</h2></caption>
                                                        <thead>
                                                            <tr>
                                                                <th>Номер</th>
                                                                <th>URL</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                    ";
            // line 310
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["link_image_url"]) ? $context["link_image_url"] : null));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
                // line 311
                echo "                                                                <tr>
                                                                    <td>";
                // line 312
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["loop"]) ? $context["loop"] : null), "index"), "html", null, true);
                echo "</td>
                                                                    <td>";
                // line 313
                echo twig_escape_filter($this->env, (isset($context["link"]) ? $context["link"] : null), "html", null, true);
                echo "</td> 
                                                                </tr>
                    ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['link'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 316
            echo "                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div><!--/span-->

                                    </div> 
";
        }
        // line 325
        echo "           ";
        if ((isset($context["last_result_analiz_link"]) ? $context["last_result_analiz_link"] : null)) {
            echo " 

                                    <div class=\"row-fluid sortable\">\t\t
                                        <div class=\"box span12\">
                                            <div class=\"box-header well\" data-original-title>
                                                <h2><i class=\"icon-user\"></i> </h2>
                                                <div class=\"box-icon\">
                                                    <a href=\"#\" class=\"btn btn-minimize btn-round\"><i class=\"icon-chevron-up\"></i></a>
                                                    <a href=\"#\" class=\"btn btn-close btn-round\"><i class=\"icon-remove\"></i></a>
                                                </div>
                                            </div> 
                                            <div class=\"box-content\">
                                                <table id=\"last_result_analiz_link\" class=\"table table-striped table-bordered bootstrap-datatable datatable analiz-link\">
                                                    <thead>
                                                        <tr>
                                                            <th>Заголовок</th>
                                                            <th>Домен</th>
                                                            <th>Действия</th>
                                                            <th style=\"display:none\">Дата создания</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                         ";
            // line 347
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["last_result_analiz_link"]) ? $context["last_result_analiz_link"] : null));
            foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
                // line 348
                echo "                                                            <tr>
                                                                <td>";
                // line 349
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["link"]) ? $context["link"] : null), "title"), "html", null, true);
                echo "</td>
                                                                <td class=\"center\">";
                // line 350
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["link"]) ? $context["link"] : null), "site"), "html", null, true);
                echo "</td>
                                                                <td class=\"center\">
                                                                    <a class=\"btn btn-success\" href=\"/a/";
                // line 352
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["link"]) ? $context["link"] : null), "site"), "html", null, true);
                echo "\">
                                                                        Результат                                            
                                                                    </a>
                                                                </td>
                                                                <td style=\"display:none\">";
                // line 356
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["link"]) ? $context["link"] : null), "create_date"), "html", null, true);
                echo "</td>
                                                            </tr>
                                                         ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['link'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 358
            echo " 
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
\t\t\t\t\t\t\t\t\t\t
                                    </div> 
    
\t";
        }
        // line 367
        echo "        
\t";
        // line 368
        if (((isset($context["status_analiz"]) ? $context["status_analiz"] : null) == true)) {
            // line 369
            echo "\t<div class=\"row-fluid sortable\">\t\t 
                                        <div class=\"box span12\">
                                            <div class=\"box-header well\" data-original-title>
                                                <h2><i class=\"icon-user\"></i> Итог анализа сайта - ";
            // line 372
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo "</h2>
                                                <div class=\"box-icon\">
                                                    <a href=\"#\" class=\"btn btn-minimize btn-round\"><i class=\"icon-chevron-up\"></i></a>
                                                    <a href=\"#\" class=\"btn btn-close btn-round\"><i class=\"icon-remove\"></i></a>
                                                </div>
                                            </div> 
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"box-content\">
\t\t\t\t\t\t\t\t\t\t\t\t\tИсходя из анализа сайта - ";
            // line 379
            echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
            echo " имеются следующие рекомендаци:
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 381
            if ((isset($context["title_url"]) ? $context["title_url"] : null)) {
                echo "<li>Заголовок сайта: <b>";
                echo (isset($context["title_url"]) ? $context["title_url"] : null);
                echo "</b> - обратите внимание что заголовок сайта это самый важный элемент в продвижении сайта, заголовок должен содержать как минимум одну ключевую фразу . Так же рекомендуется иметь заголовок не более 65 символов</li>";
            } else {
                echo "<li>Важно!!! На сайте <b>";
                echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
                echo "</b> отсутствует заголовок, значение между тегами Title в Header разделе сайта. Возможно наш сервис <b>u-set.ru</b> не смог получить значение вашего заголовка из за технических неполадок, так что проверьте в исходном коде страницы наличие тега Title . Рекомендация: заголовок сайта это самый важный элемент в продвижении сайта, заголовок должен содержать как минимум одну ключевую фразу . Так же рекомендуется иметь заголовок не более 65 символов</li>";
            }
            // line 382
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
            if ((isset($context["description_url"]) ? $context["description_url"] : null)) {
                echo "<li>Описание сайта: На сайте присутствует описание  <<<i>";
                echo (isset($context["description_url"]) ? $context["description_url"] : null);
                echo "</i>>> , этот момент один из важных для поискового продвижения сайта в интернете. Рекомендация: Описание страниц сайта должно содержать как минимум одну ключевую фразу идентичную ключевой фразе в заголовке странице и теге H1, так же рекомендуется что бы длина текста вашего описания состовляла 165 символов</li>";
            } else {
                echo "<li>Описание сайта отсутсвует!!! Исправьте это как можно быстрее для главной странице сайта ";
                echo twig_escape_filter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true);
                echo " / один из важных для поискового продвижения сайта в интернете это описание страниц. Рекомендация: Описание страниц сайта должно содержать как минимум одну ключевую фразу идентичную ключевой фразе в заголовке странице и теге H1, так же рекомендуется что бы длина текста вашего описания состовляла 165 символов  </li> ";
            }
            // line 383
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t</ul> 
\t\t\t\t\t\t\t\t\t\t\t\t</div>
                                            </div>
                                        </div> 
\t\t\t\t\t\t\t\t\t\t";
        }
        // line 388
        echo "\t<p><a href=\"http://u-set.ru\" title=\"Бесплатный Seo Анализ сайта\">Бесплатный seo анализ сайта / Сервис анализа сайта / PHP скрипт seo анализа сайта</a></p> ";
    }

    public function getTemplateName()
    {
        return "partials/result1.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  851 => 388,  844 => 383,  833 => 382,  823 => 381,  818 => 379,  808 => 372,  803 => 369,  801 => 368,  798 => 367,  786 => 358,  777 => 356,  770 => 352,  765 => 350,  761 => 349,  758 => 348,  754 => 347,  728 => 325,  717 => 316,  700 => 313,  696 => 312,  693 => 311,  676 => 310,  665 => 302,  659 => 298,  642 => 295,  637 => 293,  633 => 291,  616 => 290,  605 => 282,  602 => 281,  597 => 278,  580 => 275,  576 => 274,  573 => 273,  556 => 272,  545 => 264,  540 => 262,  514 => 241,  506 => 240,  498 => 237,  492 => 236,  484 => 233,  478 => 232,  470 => 229,  464 => 228,  457 => 224,  446 => 220,  438 => 217,  430 => 214,  426 => 212,  418 => 204,  410 => 199,  400 => 192,  392 => 186,  383 => 180,  370 => 169,  368 => 168,  352 => 163,  334 => 152,  325 => 145,  317 => 143,  313 => 141,  311 => 140,  304 => 135,  296 => 133,  292 => 131,  290 => 130,  282 => 125,  272 => 118,  268 => 117,  264 => 116,  251 => 106,  247 => 105,  243 => 104,  239 => 103,  227 => 94,  223 => 93,  219 => 92,  215 => 91,  167 => 58,  161 => 57,  148 => 55,  144 => 54,  140 => 53,  136 => 52,  131 => 51,  117 => 49,  108 => 47,  93 => 43,  89 => 42,  77 => 37,  72 => 35,  57 => 31,  42 => 21,  21 => 2,  19 => 1,  124 => 50,  121 => 27,  116 => 47,  113 => 46,  111 => 48,  107 => 26,  104 => 25,  102 => 45,  99 => 23,  90 => 20,  86 => 18,  82 => 17,  73 => 14,  69 => 12,  65 => 11,  61 => 9,  59 => 8,  55 => 6,  52 => 5,  46 => 4,  40 => 3,  32 => 2,);
    }
}
