<?php

/* pages/analiz.twig */
class __TwigTemplate_4d389d5d9f46215aa6eed93c1ed0a6a3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout/main.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'desctiption' => array($this, 'block_desctiption'),
            'keywords' => array($this, 'block_keywords'),
            'content' => array($this, 'block_content'),
            'sctipt' => array($this, 'block_sctipt'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout/main.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        echo "Анализ сайта: ";
        echo (isset($context["title_url"]) ? $context["title_url"] : null);
        echo " ";
    }

    // line 3
    public function block_desctiption($context, array $blocks = array())
    {
        echo (isset($context["description_url"]) ? $context["description_url"] : null);
    }

    // line 4
    public function block_keywords($context, array $blocks = array())
    {
        echo (isset($context["keywords_url"]) ? $context["keywords_url"] : null);
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "
<!-- form analiz -->
";
        // line 8
        $this->env->loadTemplate("partials/analizform.html")->display($context);
        // line 9
        echo "<!-- finish analiz form-->

";
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["warning"]) ? $context["warning"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 12
            echo "<div class=\"alert\">
    <button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>
    ";
            // line 14
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "
</div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 17
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["error"]) ? $context["error"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 18
            echo "<div class=\"alert alert-error\">
    <button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>
    ";
            // line 20
            echo twig_escape_filter($this->env, (isset($context["i"]) ? $context["i"] : null), "html", null, true);
            echo "
</div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 23
        echo "
";
        // line 24
        $this->env->loadTemplate("partials/result1.twig")->display($context);
        // line 25
        echo "
";
        // line 26
        if ((isset($context["last_result_analiz_link"]) ? $context["last_result_analiz_link"] : null)) {
            echo " 
                    ";
            // line 27
            $this->displayBlock('sctipt', $context, $blocks);
            // line 46
            echo "                                    ";
        }
        // line 47
        echo "
";
    }

    // line 27
    public function block_sctipt($context, array $blocks = array())
    {
        // line 28
        echo "                                <script>
                                    \$(document).ready(function() {
                                        //datatable
                                  var last_result_analiz_link =      \$(\"#last_result_analiz_link\").dataTable({
                                            \"sDom\": \"<'row-fluid'<'span6'l><'span6'f>r>t<'row-fluid'<'span12'i><'span12 center'p>>\",
                                            \"sPaginationType\": \"bootstrap\",
                                            \"oLanguage\": {
                                                \"sLengthMenu\": \"_MENU_ записей на странице\",
                                                \"sSearch\": \"Поиск: \",
                                                \"sInfo\": \"Показаны с _START_ по _END_ из _TOTAL_ записей\"
                                            },
                                        }
                                        );
                                            last_result_analiz_link.fnSort( [ [3,'desc'] ] );
                                        
                                    });
                                    </script>
";
    }

    public function getTemplateName()
    {
        return "pages/analiz.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 28,  121 => 27,  116 => 47,  113 => 46,  111 => 27,  107 => 26,  104 => 25,  102 => 24,  99 => 23,  90 => 20,  86 => 18,  82 => 17,  73 => 14,  69 => 12,  65 => 11,  61 => 9,  59 => 8,  55 => 6,  52 => 5,  46 => 4,  40 => 3,  32 => 2,);
    }
}
