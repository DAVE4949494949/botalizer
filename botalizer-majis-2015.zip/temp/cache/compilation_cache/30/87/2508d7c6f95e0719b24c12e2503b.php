<?php

/* partials/analizform.html */
class __TwigTemplate_30872508d7c6f95e0719b24c12e2503b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"row-fluid sortable ui-sortable\">
    <div class=\"box span12\" style=\"\">
        <div class=\"box-header well\" data-original-title=\"\">
            <h2><i class=\"icon icon-black icon-link\"></i> Полный seo анализ сайта </h2>
            <div class=\"box-icon\">
                <a href=\"#\" class=\"btn btn-minimize btn-round\"><i class=\"icon-chevron-up\"></i></a>
                <a href=\"#\" class=\"btn btn-close btn-round\"><i class=\"icon-remove\"></i></a>
            </div>
        </div>
        <div class=\"box-content\">
            <div class=\"row-fluid\">
                <div class=\"well center\">
                    <form class=\"form-inline\" method=\"post\" name=\"seoform\" action=\"/analiz/seo\" id=\"seoform\" onsubmit=\"return ActionSubmitAnal(this)\"> 
                        <fieldset>
                            <label class=\"control-label\" for=\"url\">Введите URL:</label>
                            <div class=\"input-prepend\">
                                <input type=\"hidden\" value=\"do\" name=\"act\">
                                <input type=\"text\" class=\"input-xxlarge\" name=\"siteurl\" value=\"\" id=\"url\" placeholder=\"http://exemple.com\"><input type=\"submit\" class=\"btn\" value=\"Анализ\" name=\"sb\" onclick=\"ActionSubmitAnal()\"/>
                            </div>
                        </fieldset>
                    </form>

                </div>               
            </div>
        </div>
    </div><!--/span-->
</div>";
    }

    public function getTemplateName()
    {
        return "partials/analizform.html";
    }

    public function getDebugInfo()
    {
        return array (  71 => 26,  55 => 14,  53 => 13,  45 => 11,  42 => 10,  26 => 6,  51 => 28,  36 => 15,  34 => 14,  19 => 1,  438 => 195,  433 => 101,  428 => 8,  423 => 7,  418 => 6,  414 => 79,  382 => 48,  378 => 46,  367 => 38,  363 => 37,  359 => 36,  355 => 35,  351 => 34,  347 => 33,  343 => 32,  339 => 31,  335 => 30,  331 => 29,  327 => 28,  323 => 27,  319 => 26,  315 => 25,  311 => 24,  307 => 23,  294 => 13,  286 => 8,  282 => 7,  278 => 6,  275 => 5,  272 => 4,  267 => 196,  265 => 195,  261 => 194,  256 => 192,  251 => 190,  246 => 188,  241 => 186,  236 => 184,  231 => 182,  226 => 180,  221 => 178,  216 => 176,  211 => 174,  206 => 172,  199 => 168,  195 => 167,  191 => 166,  187 => 165,  183 => 164,  177 => 161,  172 => 159,  167 => 157,  162 => 155,  157 => 153,  152 => 151,  147 => 149,  142 => 147,  137 => 145,  132 => 143,  127 => 141,  122 => 139,  117 => 137,  112 => 135,  107 => 133,  102 => 131,  97 => 129,  92 => 127,  87 => 124,  84 => 122,  63 => 102,  61 => 101,  47 => 90,  41 => 86,  39 => 85,  32 => 8,  30 => 7,  25 => 1,  79 => 17,  70 => 14,  66 => 12,  62 => 11,  58 => 33,  56 => 8,  52 => 6,  49 => 12,  43 => 4,  37 => 9,  31 => 2,);
    }
}
