<?php

/* layout/main.twig */
class __TwigTemplate_42c5f26edc9ca3ebad5455c6cc415388 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'desctiption' => array($this, 'block_desctiption'),
            'keywords' => array($this, 'block_keywords'),
            'content' => array($this, 'block_content'),
            'sctipt' => array($this, 'block_sctipt'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
    <head><!-- pr-cy bdeec33bbf14799dbf5a8e08cc184283 -->
        ";
        // line 4
        $this->displayBlock('head', $context, $blocks);
        // line 80
        echo " 
    </head>

    <body>
        <!-- topbar starts -->
        ";
        // line 85
        $this->env->loadTemplate("partials/topbar.html")->display($context);
        // line 86
        echo "        <!-- topbar ends -->

        <div class=\"container-fluid\">
            <div class=\"row-fluid\">
                ";
        // line 90
        $this->env->loadTemplate("partials/menu.html")->display($context);
        // line 91
        echo "                <noscript>
                <div class=\"alert alert-block span10\">
                    <h4 class=\"alert-heading\">Warning!</h4>
                    <p>You need to have JavaScript enabled to use this site.</p>
                </div>
                </noscript>
<div id=\"content\" class=\"span10\">
                    <!-- content starts -->
\t\t\t\t\t
\t\t\t\t\t\t
                    ";
        // line 101
        $this->displayBlock('content', $context, $blocks);
        // line 102
        echo "                    <!-- content finish -->
                </div>
                <!-- content ends -->
            </div><!--/#content.span10-->

        
        <footer>
            <p class=\"pull-left\">© <a href=\"http://u-set.ru\" target=\"_blank\">Неофициальный сайт  UserSet</a> </p>
            <p class=\"pull-right\">
\t    </footer>
        

        </div><!--/.fluid-container-->

    <!-- external javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->


    ";
        // line 122
        echo "    
    ";
        // line 124
        echo "

    <!-- jQuery -->
    <script src=\"";
        // line 127
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery-1.7.2.min.js\"></script>
    <!-- jQuery UI -->
    <script src=\"";
        // line 129
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery-ui-1.8.21.custom.min.js\"></script>
    <!-- transition / effect library -->
    <script src=\"";
        // line 131
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/bootstrap-transition.js\"></script>
    <!-- alert enhancer library -->
    <script src=\"";
        // line 133
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/bootstrap-alert.js\"></script>
    <!-- modal / dialog library -->
    <script src=\"";
        // line 135
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/bootstrap-modal.js\"></script>
    <!-- custom dropdown library -->
    <script src=\"";
        // line 137
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/bootstrap-dropdown.js\"></script>
    <!-- scrolspy library -->
    <script src=\"";
        // line 139
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/bootstrap-scrollspy.js\"></script>
    <!-- library for creating tabs -->
    <script src=\"";
        // line 141
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/bootstrap-tab.js\"></script>
    <!-- library for advanced tooltip -->
    <script src=\"";
        // line 143
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/bootstrap-tooltip.js\"></script>
    <!-- popover effect library -->
    <script src=\"";
        // line 145
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/bootstrap-popover.js\"></script>
    <!-- button enhancer library -->
    <script src=\"";
        // line 147
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/bootstrap-button.js\"></script>
    <!-- accordion library (optional, not used in demo) -->
    <script src=\"";
        // line 149
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/bootstrap-collapse.js\"></script>
    <!-- carousel slideshow library (optional, not used in demo) -->
    <script src=\"";
        // line 151
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/bootstrap-carousel.js\"></script>
    <!-- autocomplete library -->
    <script src=\"";
        // line 153
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/bootstrap-typeahead.js\"></script>
    <!-- tour library -->
    <script src=\"";
        // line 155
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/bootstrap-tour.js\"></script>
    <!-- library for cookie management -->
    <script src=\"";
        // line 157
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.cookie.js\"></script>
    <!-- calander plugin -->
    <script src='";
        // line 159
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/fullcalendar.min.js'></script>
    <!-- data table plugin -->
    <script src='";
        // line 161
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.dataTables.min.js'></script>

    <!-- chart libraries start -->
    <script src=\"";
        // line 164
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/excanvas.js\"></script>
    <script src=\"";
        // line 165
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.flot.min.js\"></script>
    <script src=\"";
        // line 166
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.flot.pie.min.js\"></script>
    <script src=\"";
        // line 167
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.flot.stack.js\"></script>
    <script src=\"";
        // line 168
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.flot.resize.min.js\"></script>
    <!-- chart libraries end -->

    <!-- select or dropdown enhancer -->
    <script src=\"";
        // line 172
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.chosen.min.js\"></script>
    <!-- checkbox, radio, and file input styler -->
    <script src=\"";
        // line 174
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.uniform.min.js\"></script>
    <!-- plugin for gallery image view -->
    <script src=\"";
        // line 176
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.colorbox.min.js\"></script>
    <!-- rich text editor library -->
    <script src=\"";
        // line 178
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.cleditor.min.js\"></script>
    <!-- notification plugin -->
    <script src=\"";
        // line 180
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.noty.js\"></script>
    <!-- file manager library -->
    <script src=\"";
        // line 182
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.elfinder.min.js\"></script>
    <!-- star rating plugin -->
    <script src=\"";
        // line 184
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.raty.min.js\"></script>
    <!-- for iOS style toggle switch -->
    <script src=\"";
        // line 186
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.iphone.toggle.js\"></script>
    <!-- autogrowing textarea plugin -->
    <script src=\"";
        // line 188
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.autogrow-textarea.js\"></script>
    <!-- multiple file upload plugin -->
    <script src=\"";
        // line 190
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.uploadify-3.1.min.js\"></script>
    <!-- history.js for cross-browser state change on ajax -->
    <script src=\"";
        // line 192
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/jquery.history.js\"></script>
    <!-- application script for Charisma demo -->
    <script src=\"";
        // line 194
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/js/charisma.js\"></script>
    ";
        // line 195
        $this->displayBlock('sctipt', $context, $blocks);
        // line 196
        echo "</body>
</html>";
    }

    // line 4
    public function block_head($context, array $blocks = array())
    {
        // line 5
        echo "        <meta charset=\"utf-8\">
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <meta name=\"description\" content=\"";
        // line 7
        $this->displayBlock('desctiption', $context, $blocks);
        echo "\">
        <meta name=\"keywords\" content=\"";
        // line 8
        $this->displayBlock('keywords', $context, $blocks);
        echo "\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
        <meta name=\"author\" content=\"Dmitry A Kochenov\">
        <meta name='yandex-verification' content='525202d16efc62d4' />
        <!-- The styles -->
        <link id=\"bs-css\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/bootstrap-journal.css\" rel=\"stylesheet\">
        <style type=\"text/css\">
            body {
                padding-bottom: 40px;
            }
            .sidebar-nav {
                padding: 9px 0;
            }
        </style>
\t\t<meta name=\"verify-admitad\" content=\"9d9eeb42cc\" />
        <link href=\"";
        // line 23
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/bootstrap-responsive.css\" rel=\"stylesheet\">
        <link href=\"";
        // line 24
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/charisma-app.css\" rel=\"stylesheet\">
        <link href=\"";
        // line 25
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/jquery-ui-1.8.21.custom.css\" rel=\"stylesheet\">
        <link href='";
        // line 26
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/fullcalendar.css' rel='stylesheet'>
        <link href='";
        // line 27
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/fullcalendar.print.css' rel='stylesheet'  media='print'>
        <link href='";
        // line 28
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/chosen.css' rel='stylesheet'>
        <link href='";
        // line 29
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/uniform.default.css' rel='stylesheet'>
        <link href='";
        // line 30
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/colorbox.css' rel='stylesheet'>
        <link href='";
        // line 31
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/jquery.cleditor.css' rel='stylesheet'>
        <link href='";
        // line 32
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/jquery.noty.css' rel='stylesheet'>
        <link href='";
        // line 33
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/noty_theme_default.css' rel='stylesheet'>
        <link href='";
        // line 34
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/elfinder.min.css' rel='stylesheet'>
        <link href='";
        // line 35
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/elfinder.theme.css' rel='stylesheet'>
        <link href='";
        // line 36
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/jquery.iphone.toggle.css' rel='stylesheet'>
        <link href='";
        // line 37
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/opa-icons.css' rel='stylesheet'>
        <link href='";
        // line 38
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/css/uploadify.css' rel='stylesheet'>

        <!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
          <script src=\"http://html5shim.googlecode.com/svn/trunk/html5.js\"></script>
        <![endif]-->

        <!-- The fav icon -->
        <link rel=\"shortcut icon\" href=\"";
        // line 46
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "/web/img/favicon.ico\">   
        ";
        // line 48
        echo "        <script type=\"text/javascript\">
            function ActionSubmit(th) {
                if (th.url.value == \"\") {
                    alert(\"Укажите URL который следует укоротить!\");
                    th.url.focus();
                    return false;
                }
                th.sb.disabled = true;
                return true;
            }

            function ActionSubmitAnal(th) {
                if (th.siteurl.value == \"\") {
                    alert(\"Укажите URL для выполнения анализа!\");
                    th.siteurl.focus();
                    return false;
                }
                th.sb.disabled = true;
                return true;
            }

            function change(idName) {
                if (document.getElementById(idName).style.display == 'none') {
                    document.getElementById(idName).style.display = '';
                } else {
                    document.getElementById(idName).style.display = 'none';
                }
                return false;
            }
        </script>
        ";
        // line 79
        echo "        ";
    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
    }

    // line 7
    public function block_desctiption($context, array $blocks = array())
    {
    }

    // line 8
    public function block_keywords($context, array $blocks = array())
    {
    }

    // line 101
    public function block_content($context, array $blocks = array())
    {
    }

    // line 195
    public function block_sctipt($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "layout/main.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  438 => 195,  433 => 101,  428 => 8,  423 => 7,  418 => 6,  414 => 79,  382 => 48,  378 => 46,  367 => 38,  363 => 37,  359 => 36,  355 => 35,  351 => 34,  347 => 33,  343 => 32,  339 => 31,  335 => 30,  331 => 29,  327 => 28,  323 => 27,  319 => 26,  315 => 25,  311 => 24,  307 => 23,  294 => 13,  286 => 8,  282 => 7,  278 => 6,  275 => 5,  272 => 4,  267 => 196,  265 => 195,  261 => 194,  256 => 192,  251 => 190,  246 => 188,  241 => 186,  236 => 184,  231 => 182,  226 => 180,  221 => 178,  216 => 176,  211 => 174,  206 => 172,  199 => 168,  195 => 167,  191 => 166,  187 => 165,  183 => 164,  177 => 161,  172 => 159,  167 => 157,  162 => 155,  157 => 153,  152 => 151,  147 => 149,  142 => 147,  137 => 145,  132 => 143,  127 => 141,  122 => 139,  117 => 137,  112 => 135,  107 => 133,  102 => 131,  97 => 129,  92 => 127,  87 => 124,  84 => 122,  63 => 102,  61 => 101,  47 => 90,  41 => 86,  39 => 85,  32 => 80,  30 => 4,  25 => 1,  79 => 17,  70 => 14,  66 => 12,  62 => 11,  58 => 9,  56 => 8,  52 => 6,  49 => 91,  43 => 4,  37 => 3,  31 => 2,);
    }
}
