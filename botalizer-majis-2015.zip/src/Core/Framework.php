<?php

namespace Core;

use Symfony\Component\HttpKernel\HttpKernel;
 
class Framework extends HttpKernel
{
}