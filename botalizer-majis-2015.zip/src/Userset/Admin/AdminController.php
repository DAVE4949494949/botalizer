<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AdminController
 *
 * @author koche_000
 */
class AdminController
{
    static function AdminAllShort()
    {
        
    }
}

?>
